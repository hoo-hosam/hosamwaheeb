﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace homework3
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Button5_Click(object sender, EventArgs e)
        {
            if (panel1.Visible)
            {
                panel1.Visible = false;
                button5.Text = "visible";
            }
            else
            {
                panel1.Visible = true;
                button5.Text = "unvisible";
            }

        }

        private void Button4_Click(object sender, EventArgs e)
        {
            if (panel1.Enabled)
            {
                panel1.Enabled = false;
                button4.Text = "enable";
            }

            else
            {
                panel1.Enabled = true;
                button4.Text = "disable";
            }

        }

        private void Button2_Click(object sender, EventArgs e)
        {
            int s = 0; bool f = false;
            if (checkBox1.Checked) { s += Convert.ToInt32(checkBox1.Text); f = true; }
            if (checkBox2.Checked) { s += Convert.ToInt32(checkBox2.Text); f = true; }
            if (checkBox3.Checked) { s += Convert.ToInt32(checkBox3.Text); f = true; }
            if (checkBox4.Checked) { s += Convert.ToInt32(checkBox4.Text); f = true; }
            if (f)
                textBox1.Text = s.ToString();
            else
                MessageBox.Show("no box checked");
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            if (bred.Checked)
                label3.BackColor = Color.Red;
            else if (byel.Checked)
                label3.BackColor = Color.Yellow;
            else if (bbla.Checked)
                label3.BackColor = Color.Black;
            else if (bw.Checked)
                label3.BackColor = Color.White;
            if (bsred.Checked)
                label3.ForeColor = Color.Red;
            else if (bsyel.Checked)
                label3.ForeColor = Color.Yellow;
            else if (bsg.Checked)
                label3.ForeColor = Color.Green;
            else if (bsw.Checked)
                label3.ForeColor = Color.White;
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}

namespace homework3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Button5_Click(object sender, EventArgs e)
        {
            button1.Top += 5;
            button2.Top += 5;
            button3.Top += 5;
            button4.Top += 5;
            button5.Top += 5;
            button6.Top += 5;
            button7.Top += 5;
            button8.Top += 5;
        }

        private void Button7_Click(object sender, EventArgs e)
        {
            button1.Left += 5;
            button2.Left += 5;
            button3.Left += 5;
            button4.Left += 5;
            button5.Left += 5;
            button6.Left += 5;
            button7.Left += 5;
            button8.Left += 5;
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            button1.Top -= 5;
            button2.Top -= 5;
            button3.Top -= 5;
            button4.Top -= 5;
            button5.Top -= 5;
            button6.Top -= 5;
            button7.Top -= 5;
            button8.Top -= 5;
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            button1.Left -= 5;
            button2.Left -= 5;
            button3.Left -= 5;
            button4.Left -= 5;
            button5.Left -= 5;
            button6.Left -= 5;
            button7.Left -= 5;
            button8.Left -= 5;
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            button1.Height += 5;
            button2.Height += 5;
            button3.Height += 5;
            button4.Height += 5;
            button5.Height += 5;
            button6.Height += 5;
            button7.Height += 5;
            button8.Height += 5;
        }

        private void Button8_Click(object sender, EventArgs e)
        {
            button1.Width += 5;
            button2.Width += 5;
            button3.Width += 5;
            button4.Width += 5;
            button5.Width += 5;
            button6.Width += 5;
            button7.Width += 5;
            button8.Width += 5;
        }

        private void Button6_Click(object sender, EventArgs e)
        {
            button1.Height -= 5;
            button2.Height -= 5;
            button3.Height -= 5;
            button4.Height -= 5;
            button5.Height -= 5;
            button6.Height -= 5;
            button7.Height -= 5;
            button8.Height -= 5;
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            button1.Width -= 5;
            button2.Width -= 5;
            button3.Width -= 5;
            button4.Width -= 5;
            button5.Width -= 5;
            button6.Width -= 5;
            button7.Width -= 5;
            button8.Width -= 5;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace homework3
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void Label2_Click(object sender, EventArgs e)
        {

        }
        private void operation(object s, EventArgs e)
        {
            this.Height = panel1.Height * 2;
            if (s == btnadd) { panel1.Visible = true; op.Text = "+"; panel1.BackColor = Color.Green; }
            else if (s == btnsub) { panel1.Visible = true; op.Text = "-"; panel1.BackColor = Color.Gold; }
            else if (s == btnmult) { panel1.Visible = true; op.Text = "*"; panel1.BackColor = Color.Gray; }
            else if (s == btndiv) { panel1.Visible = true; op.Text = "/"; panel1.BackColor = Color.Plum; }
        }
        double result;
        private void Button5_Click(object sender, EventArgs e)
        {
            double num1, num2;
            if (textBox1.Text.Trim() != "" && textBox2.Text.Trim() != "")
            {
                num1 = Convert.ToInt32(textBox1.Text);
                num2 = Convert.ToInt32(textBox2.Text);
                switch (op.Text)
                {
                    case "+": result = num1 + num2; break;
                    case "-": result = num1 - num2; break;
                    case "*": result = num1 * num2; break;
                    case "/":
                        {
                            if (num2 != 0) { result = num1 / num2; }
                            else
                            {
                                textBox3.Clear();
                                MessageBox.Show("divide by zero");
                                textBox2.Focus();
                            }
                            break;
                        }
                }
                textBox3.Text = result.ToString();
            }
            else
            {
                MessageBox.Show("one of the texts bars doesn't have value", "worning");
                textBox1.Focus();
            }
        }

        private void Button6_Click(object sender, EventArgs e)
        {
            Form4_Load(null, null);
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            panel1.Visible = false;
            this.Height = btnadd.Height * 5;
        }
    }
}

﻿namespace homework3
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            label3 = new Label();
            label1 = new Label();
            bw = new RadioButton();
            bbla = new RadioButton();
            byel = new RadioButton();
            bred = new RadioButton();
            panel2 = new Panel();
            button1 = new Button();
            label2 = new Label();
            bsg = new RadioButton();
            bsred = new RadioButton();
            bsw = new RadioButton();
            bsyel = new RadioButton();
            groupBox1 = new GroupBox();
            textBox1 = new TextBox();
            button2 = new Button();
            checkBox4 = new CheckBox();
            checkBox3 = new CheckBox();
            checkBox2 = new CheckBox();
            checkBox1 = new CheckBox();
            button5 = new Button();
            button4 = new Button();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(bw);
            panel1.Controls.Add(bbla);
            panel1.Controls.Add(byel);
            panel1.Controls.Add(bred);
            panel1.Location = new Point(26, 23);
            panel1.Name = "panel1";
            panel1.Size = new Size(173, 251);
            panel1.TabIndex = 0;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(46, 192);
            label3.Name = "label3";
            label3.Size = new Size(60, 30);
            label3.TabIndex = 5;
            label3.Text = "النص";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(74, 19);
            label1.Name = "label1";
            label1.Size = new Size(62, 15);
            label1.TabIndex = 4;
            label1.Text = "لون الخلفيه";
            // 
            // bw
            // 
            bw.AutoSize = true;
            bw.Location = new Point(44, 139);
            bw.Name = "bw";
            bw.RightToLeft = RightToLeft.Yes;
            bw.Size = new Size(52, 19);
            bw.TabIndex = 3;
            bw.TabStop = true;
            bw.Text = "ابيض";
            bw.UseVisualStyleBackColor = true;
            // 
            // bbla
            // 
            bbla.AutoSize = true;
            bbla.Location = new Point(46, 114);
            bbla.Name = "bbla";
            bbla.RightToLeft = RightToLeft.Yes;
            bbla.Size = new Size(50, 19);
            bbla.TabIndex = 2;
            bbla.TabStop = true;
            bbla.Text = "اسود";
            bbla.UseVisualStyleBackColor = true;
            bbla.CheckedChanged += radioButton3_CheckedChanged;
            // 
            // byel
            // 
            byel.AutoSize = true;
            byel.Location = new Point(46, 89);
            byel.Name = "byel";
            byel.RightToLeft = RightToLeft.Yes;
            byel.Size = new Size(51, 19);
            byel.TabIndex = 1;
            byel.TabStop = true;
            byel.Text = "اصفر";
            byel.UseVisualStyleBackColor = true;
            // 
            // bred
            // 
            bred.AutoSize = true;
            bred.Location = new Point(50, 64);
            bred.Name = "bred";
            bred.RightToLeft = RightToLeft.Yes;
            bred.Size = new Size(47, 19);
            bred.TabIndex = 0;
            bred.TabStop = true;
            bred.Text = "احمر";
            bred.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            panel2.Controls.Add(button1);
            panel2.Controls.Add(label2);
            panel2.Controls.Add(bsg);
            panel2.Controls.Add(bsred);
            panel2.Controls.Add(bsw);
            panel2.Controls.Add(bsyel);
            panel2.Location = new Point(215, 23);
            panel2.Name = "panel2";
            panel2.Size = new Size(168, 254);
            panel2.TabIndex = 1;
            // 
            // button1
            // 
            button1.Location = new Point(50, 192);
            button1.Name = "button1";
            button1.Size = new Size(75, 34);
            button1.TabIndex = 6;
            button1.Text = "تطبيق";
            button1.UseVisualStyleBackColor = true;
            button1.Click += Button1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(63, 19);
            label2.Name = "label2";
            label2.Size = new Size(55, 15);
            label2.TabIndex = 5;
            label2.Text = "لون النص";
            // 
            // bsg
            // 
            bsg.AutoSize = true;
            bsg.Location = new Point(47, 139);
            bsg.Name = "bsg";
            bsg.RightToLeft = RightToLeft.Yes;
            bsg.Size = new Size(51, 19);
            bsg.TabIndex = 4;
            bsg.TabStop = true;
            bsg.Text = "اخضر";
            bsg.UseVisualStyleBackColor = true;
            // 
            // bsred
            // 
            bsred.AutoSize = true;
            bsred.Location = new Point(51, 113);
            bsred.Name = "bsred";
            bsred.RightToLeft = RightToLeft.Yes;
            bsred.Size = new Size(47, 19);
            bsred.TabIndex = 3;
            bsred.TabStop = true;
            bsred.Text = "احمر";
            bsred.UseVisualStyleBackColor = true;
            // 
            // bsw
            // 
            bsw.AutoSize = true;
            bsw.Location = new Point(46, 90);
            bsw.Name = "bsw";
            bsw.RightToLeft = RightToLeft.Yes;
            bsw.Size = new Size(52, 19);
            bsw.TabIndex = 2;
            bsw.TabStop = true;
            bsw.Text = "ابيض";
            bsw.UseVisualStyleBackColor = true;
            // 
            // bsyel
            // 
            bsyel.AutoSize = true;
            bsyel.Location = new Point(47, 64);
            bsyel.Name = "bsyel";
            bsyel.RightToLeft = RightToLeft.Yes;
            bsyel.Size = new Size(51, 19);
            bsyel.TabIndex = 1;
            bsyel.TabStop = true;
            bsyel.Text = "اصفر";
            bsyel.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(textBox1);
            groupBox1.Controls.Add(button2);
            groupBox1.Controls.Add(checkBox4);
            groupBox1.Controls.Add(checkBox3);
            groupBox1.Controls.Add(checkBox2);
            groupBox1.Controls.Add(checkBox1);
            groupBox1.Location = new Point(407, 23);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(191, 251);
            groupBox1.TabIndex = 2;
            groupBox1.TabStop = false;
            groupBox1.Text = "groupBox1";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(37, 203);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(100, 23);
            textBox1.TabIndex = 7;
            // 
            // button2
            // 
            button2.Location = new Point(6, 165);
            button2.Name = "button2";
            button2.Size = new Size(167, 25);
            button2.TabIndex = 6;
            button2.Text = "حساب";
            button2.UseVisualStyleBackColor = true;
            button2.Click += Button2_Click;
            // 
            // checkBox4
            // 
            checkBox4.AutoSize = true;
            checkBox4.Location = new Point(26, 140);
            checkBox4.Name = "checkBox4";
            checkBox4.Size = new Size(44, 19);
            checkBox4.TabIndex = 3;
            checkBox4.Text = "400";
            checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            checkBox3.AutoSize = true;
            checkBox3.Location = new Point(26, 114);
            checkBox3.Name = "checkBox3";
            checkBox3.Size = new Size(44, 19);
            checkBox3.TabIndex = 2;
            checkBox3.Text = "300";
            checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            checkBox2.AutoSize = true;
            checkBox2.Location = new Point(26, 90);
            checkBox2.Name = "checkBox2";
            checkBox2.Size = new Size(44, 19);
            checkBox2.TabIndex = 1;
            checkBox2.Text = "200";
            checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Location = new Point(26, 65);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(44, 19);
            checkBox1.TabIndex = 0;
            checkBox1.Text = "100";
            checkBox1.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            button5.Location = new Point(124, 303);
            button5.Name = "button5";
            button5.Size = new Size(75, 37);
            button5.TabIndex = 3;
            button5.Text = "شفاف";
            button5.UseVisualStyleBackColor = true;
            button5.Click += Button5_Click;
            // 
            // button4
            // 
            button4.Location = new Point(280, 303);
            button4.Name = "button4";
            button4.Size = new Size(75, 37);
            button4.TabIndex = 4;
            button4.Text = "اظهار";
            button4.UseVisualStyleBackColor = true;
            button4.Click += Button4_Click;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(654, 378);
            Controls.Add(button4);
            Controls.Add(button5);
            Controls.Add(groupBox1);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Name = "Form2";
            Text = "Form2";
            Load += Form2_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private RadioButton bw;
        private RadioButton bbla;
        private RadioButton byel;
        private RadioButton bred;
        private Panel panel2;
        private RadioButton bsg;
        private RadioButton bsred;
        private RadioButton bsw;
        private RadioButton bsyel;
        private GroupBox groupBox1;
        private Label label1;
        private Label label2;
        private CheckBox checkBox4;
        private CheckBox checkBox3;
        private CheckBox checkBox2;
        private CheckBox checkBox1;
        private Label label3;
        private Button button1;
        private Button button2;
        private Button button5;
        private Button button4;
        private TextBox textBox1;
    }
}
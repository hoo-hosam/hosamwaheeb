﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace homework3
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        Thread threadgo;
        private void Button3_Click(object sender, EventArgs e)
        {
            threadgo = new Thread(go);
            threadgo.Start();
            void go()
            {
                for (int i = 0; i <= this.Width - button1.Width; i+=5)
                {
                    Invoke((Action)(() =>
                    {
                        button1.Left += 5;
                    }));
                    Thread.Sleep(10);
                }
                for (int i = 0; i < this.Width - button1.Width; i+=5)
                {
                    Invoke((Action)(() =>
                    {
                        button1.Left += 5;
                    }));
                    Thread.Sleep(10);
                }
            }

        }


        private void Button4_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < this.Height - button2.Height; i+=5)
            {
                button2.Top += 5;
                Thread.Sleep(100);
                Application.DoEvents();
            }
            for (int i = 0; i < this.Height - button2.Height; i+=5)
            {
                button2.Top -= 5;
                Thread.Sleep(100);
                Application.DoEvents();
            }
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }
    }
}
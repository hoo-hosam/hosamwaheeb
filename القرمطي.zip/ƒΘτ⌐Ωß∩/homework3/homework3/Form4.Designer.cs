﻿namespace homework3
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            label4 = new Label();
            op = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            button6 = new Button();
            button5 = new Button();
            textBox3 = new TextBox();
            textBox2 = new TextBox();
            textBox1 = new TextBox();
            btnadd = new Button();
            btnsub = new Button();
            btnmult = new Button();
            btndiv = new Button();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(label4);
            panel1.Controls.Add(op);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(button6);
            panel1.Controls.Add(button5);
            panel1.Controls.Add(textBox3);
            panel1.Controls.Add(textBox2);
            panel1.Controls.Add(textBox1);
            panel1.Location = new Point(31, 86);
            panel1.Name = "panel1";
            panel1.Size = new Size(467, 224);
            panel1.TabIndex = 0;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(132, 91);
            label4.Name = "label4";
            label4.Size = new Size(15, 15);
            label4.TabIndex = 9;
            label4.Text = "=";
            // 
            // op
            // 
            op.AutoSize = true;
            op.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            op.Location = new Point(305, 91);
            op.Name = "op";
            op.Size = new Size(45, 17);
            op.TabIndex = 8;
            op.Text = "label4";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(48, 51);
            label3.Name = "label3";
            label3.Size = new Size(32, 15);
            label3.TabIndex = 7;
            label3.Text = "الناتج";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(220, 47);
            label2.Name = "label2";
            label2.Size = new Size(64, 15);
            label2.TabIndex = 6;
            label2.Text = "العدد الثاني";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(391, 47);
            label1.Name = "label1";
            label1.Size = new Size(60, 15);
            label1.TabIndex = 5;
            label1.Text = "العدد الأول";
            // 
            // button6
            // 
            button6.Location = new Point(13, 166);
            button6.Name = "button6";
            button6.Size = new Size(75, 23);
            button6.TabIndex = 4;
            button6.Text = "إغلاق";
            button6.UseVisualStyleBackColor = true;
            button6.Click += Button6_Click;
            // 
            // button5
            // 
            button5.Location = new Point(376, 157);
            button5.Name = "button5";
            button5.Size = new Size(75, 23);
            button5.TabIndex = 3;
            button5.Text = "حساب";
            button5.UseVisualStyleBackColor = true;
            button5.Click += Button5_Click;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(13, 83);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(100, 23);
            textBox3.TabIndex = 2;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(185, 83);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(100, 23);
            textBox2.TabIndex = 1;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(351, 83);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(100, 23);
            textBox1.TabIndex = 0;
            // 
            // btnadd
            // 
            btnadd.BackColor = SystemColors.MenuHighlight;
            btnadd.Location = new Point(423, 39);
            btnadd.Name = "btnadd";
            btnadd.Size = new Size(75, 23);
            btnadd.TabIndex = 1;
            btnadd.Text = "جمع";
            btnadd.UseVisualStyleBackColor = false;
            btnadd.Click += operation;
            // 
            // btnsub
            // 
            btnsub.BackColor = SystemColors.MenuHighlight;
            btnsub.Location = new Point(299, 39);
            btnsub.Name = "btnsub";
            btnsub.Size = new Size(75, 23);
            btnsub.TabIndex = 2;
            btnsub.Text = "طرح";
            btnsub.UseVisualStyleBackColor = false;
            btnsub.Click += operation;
            // 
            // btnmult
            // 
            btnmult.BackColor = SystemColors.MenuHighlight;
            btnmult.Location = new Point(153, 39);
            btnmult.Name = "btnmult";
            btnmult.Size = new Size(75, 23);
            btnmult.TabIndex = 3;
            btnmult.Text = "ضرب";
            btnmult.UseVisualStyleBackColor = false;
            btnmult.Click += operation;
            // 
            // btndiv
            // 
            btndiv.BackColor = SystemColors.MenuHighlight;
            btndiv.Location = new Point(31, 39);
            btndiv.Name = "btndiv";
            btndiv.Size = new Size(75, 23);
            btndiv.TabIndex = 4;
            btndiv.Text = "قسمه";
            btndiv.UseVisualStyleBackColor = false;
            btndiv.Click += operation;
            // 
            // Form4
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(522, 347);
            Controls.Add(btndiv);
            Controls.Add(btnmult);
            Controls.Add(btnsub);
            Controls.Add(btnadd);
            Controls.Add(panel1);
            Name = "Form4";
            Text = "Form4";
            Load += Form4_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private TextBox textBox3;
        private TextBox textBox2;
        private TextBox textBox1;
        private Button btnadd;
        private Button btnsub;
        private Button btnmult;
        private Label label3;
        private Label label2;
        private Label label1;
        private Button button6;
        private Button button5;
        private Button btndiv;
        private Label op;
        private Label label4;
    }
}
namespace اله_حاسبة
{
    public partial class Form1 : Form
    {
        double number1, number2, result;
        char op;
        public Form1()
        {
            InitializeComponent();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            hosam.Text = hosam.Text + "7";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            hosam.Text = hosam.Text + "1";
            //  hosam.Text +="1"; 
        }

        private void button2_Click(object sender, EventArgs e)
        {
            hosam.Text = hosam.Text + "2";
        }

        private void button12_Click(object sender, EventArgs e)
        {
            hosam.Text = hosam.Text + "2";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            hosam.Text = hosam.Text + "4";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            hosam.Text = hosam.Text + "5";
        }

        private void button11_Click(object sender, EventArgs e)
        {
            hosam.Text = hosam.Text + "6";
        }

        private void button7_Click(object sender, EventArgs e)
        {
            hosam.Text = hosam.Text + "8";
        }

        private void button10_Click(object sender, EventArgs e)
        {
            hosam.Text = hosam.Text + "9";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            hosam.Text = hosam.Text + "0";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            hosam.Text = hosam.Text + ".";
        }

        private void button9_Click(object sender, EventArgs e)
        {
            hosam.Clear();
        }

        private void button16_Click(object sender, EventArgs e)
        {
            number1 = Convert.ToDouble(hosam.Text);
            op = '+';
            hosam.Clear();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            number1 = Convert.ToDouble(hosam.Text);
            op = '-';
            hosam.Clear();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            number1 = Convert.ToDouble(hosam.Text);
            op = '*';
            hosam.Clear();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            number1 = Convert.ToDouble(hosam.Text);
            op = '/';
            hosam.Clear();
        }

        private void button17_Click(object sender, EventArgs e)
        {
            number2=Convert.ToDouble(hosam.Text);
            switch (op)
            {
                case '+':
                    result = number1 + number2; break;
                case '-':
                    result = number1 - number2; break;
                case '*':
                    result = number1 * number2; break;
                case '/':
                    result = number1 / number2; break;
            }
            hosam.Text=Convert.ToString(result);
        }
    }
}

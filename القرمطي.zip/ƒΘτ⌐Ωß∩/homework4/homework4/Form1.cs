using System.Windows.Forms;

namespace homework4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Open(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                Bitmap b = new Bitmap(openFileDialog1.FileName);
                textBox1.Text = openFileDialog1.FileName;
                pictureBox1.Image = b;
            }
            else
            {
                MessageBox.Show("enter your image");
            }


        }

        private void Close(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Del(object sender, EventArgs e)
        {
            pictureBox1.Image = null;
            textBox1.Text = "";
        }

        private void Form1_Load_1(object sender, EventArgs e)
        {

        }
    }
}

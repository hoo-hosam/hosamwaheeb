﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace homework4
{
    public partial class Form3 : Form
    {
        string[] da = { "Sat", "Sun", "Mon", "Tues", "Wed", "Thu", "Fri" };

        public Form3()
        {
            InitializeComponent();
        }

        private void Start(object sender, EventArgs e)
        {
            timer1.Interval = 1000;
            timer1.Start();
        }

        private void Stop(object sender, EventArgs e)
        {
            timer1.Stop();
            this.Close();
        }
        int s = -1, m = 0, h = 0, d = 0;

        private void Form4_Load(object sender, EventArgs e)
        {

        }
        int i = 0;
        private void Tic_Tac(object sender, EventArgs e)
        {
            s++;
            if (s > 9)
                label1.Text = s.ToString();
            else
                label1.Text = "0" + s.ToString();
            if (s >= 59)
            {
                s = 0;
                m++;

                if (m > 9)
                    label5.Text = m.ToString();
                else
                    label5.Text = "0" + m.ToString();


            }
            if (m >= 59)
            {
                m = 0;
                h++;
                if (h > 9)
                    label7.Text = h.ToString();
                else
                    label7.Text = "0" + h.ToString();
            }
            if (h >= 23)
            {
                h = 0;
                d++;
                if (d > 9)
                    label10.Text = d.ToString();
                else
                    label10.Text = "0" + d.ToString();
                i++;
                if (i >= 7)
                {
                    i = 0;
                    label4.Text = da[i];
                }
                else
                {
                    label4.Text = da[i];
                }
            }

        }
    }
}

﻿namespace homework2
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnaqua = new Button();
            btnkhaki = new Button();
            btnplu = new Button();
            button5 = new Button();
            device1 = new Label();
            device2 = new Label();
            SuspendLayout();
            // 
            // btnaqua
            // 
            btnaqua.BackColor = Color.Aqua;
            btnaqua.Location = new Point(52, 104);
            btnaqua.Name = "btnaqua";
            btnaqua.Size = new Size(80, 65);
            btnaqua.TabIndex = 0;
            btnaqua.Text = "سماوي";
            btnaqua.UseVisualStyleBackColor = false;
            // 
            // btnkhaki
            // 
            btnkhaki.BackColor = Color.Khaki;
            btnkhaki.Location = new Point(168, 104);
            btnkhaki.Name = "btnkhaki";
            btnkhaki.Size = new Size(80, 65);
            btnkhaki.TabIndex = 1;
            btnkhaki.Text = "اصفر";
            btnkhaki.UseVisualStyleBackColor = false;
            btnkhaki.Click += Btngre_Click;
            // 
            // btnplu
            // 
            btnplu.BackColor = Color.Plum;
            btnplu.Location = new Point(290, 104);
            btnplu.Name = "btnplu";
            btnplu.Size = new Size(80, 65);
            btnplu.TabIndex = 2;
            btnplu.Text = "بنفسجي";
            btnplu.UseVisualStyleBackColor = false;
            // 
            // button5
            // 
            button5.Location = new Point(139, 232);
            button5.Name = "button5";
            button5.Size = new Size(147, 89);
            button5.TabIndex = 3;
            button5.Text = "حسام";
            button5.UseVisualStyleBackColor = true;
            // 
            // device1
            // 
            device1.AutoSize = true;
            device1.Location = new Point(52, 47);
            device1.Name = "device1";
            device1.Size = new Size(43, 15);
            device1.TabIndex = 4;
            device1.Text = "hosam";
            // 
            // device2
            // 
            device2.AutoSize = true;
            device2.Location = new Point(290, 47);
            device2.Name = "device2";
            device2.Size = new Size(51, 15);
            device2.TabIndex = 5;
            device2.Text = "القرمطي";
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(416, 388);
            Controls.Add(device2);
            Controls.Add(device1);
            Controls.Add(button5);
            Controls.Add(btnplu);
            Controls.Add(btnkhaki);
            Controls.Add(btnaqua);
            Name = "Form2";
            Text = "Form2";
            Load += Form2_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnaqua;
        private Button btnkhaki;
        private Button btnplu;
        private Button button5;
        private Label device1;
        private Label device2;
    }
}
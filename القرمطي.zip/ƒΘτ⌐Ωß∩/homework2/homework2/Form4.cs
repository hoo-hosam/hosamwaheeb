﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace homework2
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            label2.Text = "";
            label3.Text = "";
            label4.Text = "";
            textBox1.Clear();
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            double num = Convert.ToDouble(textBox1.Text);

            label4.Text = Math.Pow(num, 0.5).ToString();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            double num = Convert.ToDouble(textBox1.Text);

            long fact = 1;
            for (int i = 1; i <= num; i++)
            {
                fact *= i;
            }
            label3.Text = fact.ToString();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            double num = Convert.ToDouble(textBox1.Text);

            int sum = 0;
            for (int i = 1; i <= num; i++)
            {
                sum += i;
            }
            label2.Text = sum.ToString();
        }

        private void Button5_Click(object sender, EventArgs e)
        {
            DialogResult Result = MessageBox.Show("Do You Really Want Exit ?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (Result == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void حذف(object sender, EventArgs e)
        {

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace homework2
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            btnaqua.Click += new EventHandler(trainforSender);
            btnkhaki.Click += new EventHandler(trainforSender);
            btnplu.Click += new EventHandler(trainforSender);

            device1.Click += new EventHandler(trainforSender);
            device2.Click += new EventHandler(trainforSender);


        }
        private void trainforSender(object s, EventArgs e)
        {
            if (s == btnaqua)
            {
                button5.BackColor = Color.Aqua;
            }
            else if (s == btnplu)
            {
                button5.BackColor = Color.Plum;
            }
            else if (s == btnkhaki)
            {
                button5.BackColor = Color.Khaki;
            }
            else if (s == device1)
            {
                button5.Text = device1.Text;
            }
            else if (s == device2)
            {
                button5.Text = device2.Text;
            }
            //هنا قمنا بختبار السيندر بهل هو يشبه الزر او اللايبيل ثم نستطيع تحويله بعدها
        }

        private void Btngre_Click(object sender, EventArgs e)
        {

        }
    }
}

namespace homework2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private double CalaculateWithPriority(double Number1, double Number2, double Number3, string Opertion1, string Opertion2)
        {
            double intermediateResult;
            if (double.TryParse(textBox1.Text, out Number1) &&
                double.TryParse(textBox3.Text, out Number2) &&
                double.TryParse(textBox5.Text, out Number3))
            {
                if (Opertion1 == "*" || Opertion1 == "/")
                {
                    intermediateResult = FormOfOpertion(Number1, Number2, Opertion1);

                    return FormOfOpertion(intermediateResult, Number3, Opertion2);
                }
                else if (Opertion2 == "*" || Opertion2 == "/")
                {
                    intermediateResult = FormOfOpertion(Number2, Number3, Opertion2);

                    return FormOfOpertion(Number1, intermediateResult, Opertion1);
                }
                else
                {
                    intermediateResult = FormOfOpertion(Number1, Number2, Opertion1);
                    return FormOfOpertion(intermediateResult, Number3, Opertion2);
                }

            }
            else
            {
                MessageBox.Show("Error", "Please Enter Correct Number !", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return double.NaN;
            }

        }
        private double FormOfOpertion(double num1, double num2, string op)
        {
            switch (op)
            {
                case "+":
                    return (num1 + num2);
                case "-":
                    return (num1 - num2);
                case "*":
                    return (num1 * num2);
                case "/":
                    if (num2 != 0)
                    {
                        return num1 / num2;
                    }
                    else
                    {
                        textBox6.Text = "";
                        MessageBox.Show("Divtion By Zero", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        textBox6.Text = textBox3.Text = "";
                        textBox3.Focus();
                        return Double.NaN;
                    }
                default:
                    MessageBox.Show("Invalid Opertion", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return Double.NaN;
            }

        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Button2_Click(object sender, EventArgs e)
        {
            double Number1 = double.Parse(textBox1.Text);
            double Number2 = double.Parse(textBox3.Text);
            double Number3 = double.Parse(textBox5.Text);

            string Opertion1 = textBox2.Text;
            string Opertion2 = textBox4.Text;

            double finalResult = CalaculateWithPriority(Number1, Number2, Number3, Opertion1, Opertion2);
            textBox6.Text = finalResult.ToString();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

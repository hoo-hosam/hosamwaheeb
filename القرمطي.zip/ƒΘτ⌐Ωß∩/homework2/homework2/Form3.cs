﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace homework2
{
    public partial class Form3 : Form
    {
        double num1, num2, result;
        string[] Opertion = { "+", "-", "/", "*" };
        public Form3()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            DialogResult Result = MessageBox.Show("Do You Really Want Exit ?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (Result == DialogResult.Yes)
            {
                this.Close();
            }
        }
        private void functiontoOpertion(double num1, double num2)
        {
            bool f = true;
            switch (listBox1.SelectedIndex) //comboBox1.SelectedIndex
            {
                default: break;
                case 0: result = num1 + num2; break;
                case 1: result = num1 - num2; break;
                case 2: result = num1 * num2; break;
                case 3:
                    if (num2 != 0)
                    {
                        result = num1 / num2;
                        break;
                    }
                    else
                    {
                        // to avoid make value in result when we Divtion by Zero
                        textBox3.Text = null;

                        MessageBox.Show("Error", "Divtion By Zero ! ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        f = false;
                        textBox2.Text = null;
                        textBox2.Focus();
                    }
                    break;
            }
            if (f)
            {
                textBox3.Text = result.ToString();
            }
        }
        private void callFunction()
        {
            try
            {
                num1 = Convert.ToDouble(textBox1.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("The Frist is false ! ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                textBox1.Text = "";
                textBox1.Focus();
                return;
            }

            try
            {
                num2 = Convert.ToDouble(textBox2.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("The Second is false ! ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                textBox2.Text = "";
                textBox2.Focus();
                return;
            }
            functiontoOpertion(num1, num2);
        }

        private void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Button3_Click(object sender, EventArgs e)
        {
            callFunction();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void Button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox2.Text = textBox3.Text = null;
        }
    }
}
